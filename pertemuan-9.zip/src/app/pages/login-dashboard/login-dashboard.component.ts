import { Component } from '@angular/core';

@Component({
  selector: 'app-login-dashboard',
  standalone: false,
  templateUrl: './login-dashboard.component.html',
  styleUrl: './login-dashboard.component.scss'
})
export class LoginDashboardComponent {

}
