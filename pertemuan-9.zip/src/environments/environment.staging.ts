export const environment = {
    production: false,
    domainStaging: 'https://api.env-testing.com'
}